# Caper: parser generator

Caper is a modern parser generator.
Caper emits C++, Java, JavaScript, D, C#, Boo code.

## Documents

* http://jonigata.github.io/caper/caper.html (ja)
* http://jonigata.github.io/caper/en/caper.html (en)

## Other Documents (Japanese)

### Introduction

* http://qiita.com/jonigata/items/2a4e3b642afd20970eb2

### Implementing GLR

* http://qiita.com/jonigata/items/69381937b2d5b0af410c
* http://qiita.com/jonigata/items/fc1764dde1fa62cdac2f
* http://qiita.com/jonigata/items/f7d23a5d8e14137e7fe0

## Contact

twitter: @jonigata
